import openpyxl

def find_info_by_name(excel_file, name_to_find):
    try:
        # 打开Excel文件
        workbook = openpyxl.load_workbook(excel_file)
        sheet = workbook.active

        # 初始化一个列表来存储匹配的信息
        info_list = []

        # 遍历每一行，查找匹配的名称并将信息添加到列表中
        for row in sheet.iter_rows(values_only=True):
            if row[0] == name_to_find:
                info = [row[0], row[1]]
                info_list.append(info)

        # 关闭Excel文件
        workbook.close()

        return info_list

    except Exception as e:
        print("发生错误:", e)
        return []

# 替换成你的Excel文件路径
excel_file = "E:\Web开发\病媒识别4\病媒生物介绍.xlsx"

# 从前端获取用户输入的名称
input_name = input("请输入要查找的名称: ")

# 调用函数查找并打印信息
result = find_info_by_name(excel_file, input_name)

if result:
    print("找到的信息:")
    for info in result:
        print("名称:", info[0])
        print("信息:", info[1])
else:
    print("未找到匹配的信息.")


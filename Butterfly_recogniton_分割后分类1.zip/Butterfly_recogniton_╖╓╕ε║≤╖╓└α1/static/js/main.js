// 预测多张
$(document).ready(function () {
    // Init
    $('.image-section').hide();
    $('.loader').hide();
    $('#print_res').hide();

    // Upload Preview
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagePreview').css('background-image', 'url(' + e.target.result + ')');
                $('#imagePreview').hide();
                $('#imagePreview').fadeIn(650);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imageUpload").change(function () {
        $('.image-section').show();
        $('#btn-predict').show();
        $('#result_list').text('');
        $('#result_list').hide();
        readURL(this);

        // 显示上传的照片预览
        $(".uploaded-images").empty();
        for (var i = 0; i < this.files.length; i++) {
            var imgPreview = document.createElement("img");
            imgPreview.src = URL.createObjectURL(this.files[i]);
            $(".uploaded-images").append(imgPreview);
        }
    });

    // Predict
    $('#btn-predict').click(function () {
        var form_data = new FormData($('#upload-file')[0]);

        // Show loading animation
        $(this).hide();
        $('.loader').show();

        // Make prediction by calling api /predict
        $.ajax({
            type: 'POST',
            url: '/predict',
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            async: true,
            success: function(response) {
                $('.loader').hide();
                $('#result_list').empty();

                // 假设 'response' 是一个对象，包含 'results' 和 'segmented_images'
                var data = response.results;
                var segmentedImages = response.segmented_images;

                data.forEach(function(result) {
                    $('#result_list').append('<p>' + result + '</p>');
                });

                // 显示分割后的图像
                $('#result_fenge').empty();
                segmentedImages.forEach(function(imageUrl) {
                    $('#result_fenge').append('<img src="' + imageUrl + '" />');
                });

                $('#result_list').fadeIn(600);
                $('#result_fenge').fadeIn(600);
                console.log('Success!');
            },
            // success:
            //     function (data) {
            //     $('.loader').hide();
            //     $('#result_list').empty();
            //
            //     data.forEach(function(result) {
            //         $('#result_list').append('<p>' + result + '</p>');
            //     });
            //
            //     // 显示结果
            //     $('#result_list').fadeIn(600);
            //     console.log('Success!');
            // },
        });
    });

});
